java -cp aiwolf-server.jar:aiwolf-common.jar:aiwolf-viewer.jar org.aiwolf.ui.log.GUILogViewerStarter
read Wait